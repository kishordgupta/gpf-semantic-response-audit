# Data dictionary

The released CSV has **7,056 rows and exactly 28 columns**, in the order below. It preserves the supplied selected-column dataset without modifying response or prompt text. The row key validated by the analysis is `(model_name, cell_id)`, not `run_id`. Empty CSV strings represent unavailable or unrecorded metadata, not numerical zero.

| Column | Stored type | Meaning and analytical use |
|---|---|---|
| `run_id` | string | Recorded generation/run identifier. It is inherited across some AUC and Gemini records and is not a globally unique row key. Retained for provenance, not used alone to join observations. |
| `cell_id` | string | Frozen experimental condition identifier encoding the article, Y label, and prompt family. The same condition appears for every model. The validated row key is (model_name, cell_id). |
| `experiment_stage` | categorical string | Recorded collection stage: primary or external_platform_extension. This is provenance rather than an independent experimental treatment; extension describes the Grok stream. |
| `repeat` | integer | Requested generation replicate index. Every supplied row has repeat=1, so within-condition generation variance cannot be estimated. |
| `model_name` | categorical string | Human-facing model label recorded during collection; twelve labels, 588 rows each. UI labels and latest aliases do not independently verify hidden serving checkpoints. |
| `model_id` | string | Recorded routing or model identifier. It may be a mutable latest alias, a UI alias, or unknown. Do not interpret it as a pinned model-weight revision. |
| `model_provider` | categorical string | Recorded serving provider or route. Values include together_ai and openrouter for Meta-family models; this column does not consistently identify the model developer. Analysis derives company from model family separately. |
| `prompt_family` | categorical string | One of seven question objectives: significance, impact, emotion, worldview, community, bias_check, or policy_action. Used as a controlled comparison stratum. |
| `prompt_question` | string | Identity-conditioned question, including the exact I am Y wording. The wording can itself elicit prescriptions or assumptions, especially in emotion and worldview questions. |
| `full_prompt` | multiline string | Exact frozen user prompt, including instructions, identity-conditioned question, source metadata, URL, and supplied article text. All twelve rows for a cell have the same string. Contains publisher-owned news content; handle as a private research artifact. |
| `x_group_id` | categorical string | Article identifier: bbc_brewdog or reuters_denmark. X is the source-news condition, not a participant group. |
| `x_group_name` | string | Article title captured for the X condition. Titles describe the articles used; they are not model outputs. |
| `news_source` | categorical string | Source label: BBC News or Reuters via Internazionale. Only one article per source is present, so source, article, topic, and supplied length are confounded. |
| `news_source_link` | URL string | Recorded source page URL. A provenance reference, not a guarantee that the page remains unchanged or accessible. Responses were requested to use supplied text without browsing. |
| `news_author` | string | Byline captured from source metadata: Paul Hastie for BBC and Stine Jacobsen for the Reuters item. |
| `news_published_utc` | date/time string | Publication metadata preserved as collected. BBC has a UTC timestamp; Reuters has only 2026-09-18, so exact time of day is unavailable. Do not silently impute a time. |
| `news_modified_utc` | nullable date/time string | Source modification timestamp when available. Blank for all 3,528 Reuters rows; blank means unknown rather than unchanged. |
| `news_retrieved_utc` | date/time string | Recorded UTC article retrieval time. Shared across all responses to an article; not the response capture time. |
| `news_word_count` | integer | Recorded article-body word count: BBC 571 and Reuters 204. It does not count the entire prompt or model response. |
| `y_group_dimension` | categorical string | Design partition for the identity phrase: gender_sexuality, geography, political, race_ethnicity, religion, or socioeconomic. These inherited categories mix overlapping constructs and are not a validated demographic taxonomy. |
| `y_group_id` | string | Stable design label combining dimension and identity name. Used for matching and clustered uncertainty; it does not identify a person. |
| `y_group_name` | categorical string | Exact synthetic self-description inserted into the prompt. There are 42 labels with 14 prompts and 168 responses per label. These are experimental text perturbations, not sampled communities or measured attributes. |
| `response` | multiline string | Captured response text. The release preserves text verbatim, including some UI headings or citation-like fragments. Analysis removes only known leading UI wrappers and normalizes whitespace. Content anomalies remain flagged, not silently repaired. |
| `response_word_count` | integer | Stored collection-time word count. It can differ from the analysis recount after removal of UI wrappers and standardized whitespace splitting. Recomputed counts are provided in results/word_count_audit.csv. |
| `captured_utc` | date/time string | Recorded UTC capture timestamp, spanning September 19-27, 2026. This is collection provenance and may not be exact generation-start time or an independently audited server timestamp. |
| `requested_word_range` | string | Prompt length instruction, 100-150 words. This is a requested range, not an inclusion filter; long and short responses are retained. |
| `length_status` | categorical string | Stored within/outside-range label derived during dataset construction. Analysis reports its own consistently recounted length compliance and a both-responses-compliant sensitivity analysis. |
| `thread_deleted` | nullable boolean string | Historical collection flag, true or false for Gemini and blank for other streams. It is not independent verification of deletion, retention, or temporary-chat state; blank means unrecorded. No account-security conclusion follows from this field. |

## Why the Y labels matter

Y is an experimentally varied self-description in the question. Holding article, question family, and model fixed makes it possible to measure how the captured wording changes across Y labels. Holding the entire prompt fixed makes model-to-model distances interpretable as observed output differences for that condition. Neither comparison estimates the importance, worth, preferences, or real experiences of people in the named groups. Semantic distance alone does not establish discrimination, stereotype endorsement, factual error, or harm.

All 42 labels have equal exposure: two articles × seven prompt families = 14 prompts per model and 168 responses across twelve models. Each pair of models is matched on exactly the same frozen prompt.

| Design dimension | Labels | Number |
|---|---|---|
| `gender_sexuality` | Bisexual; Gay Male; LGBTQ+; Lesbian; Nonbinary; Straight Female; Straight Male; Transgender / Nonbinary | 8 |
| `geography` | Coastal Elite; Midwest working-class White; Rural American; Southeastern Black; Southwestern Hispanic; Urban American | 6 |
| `political` | Conservative; Democrat; Independent; Liberal; Socialist | 5 |
| `race_ethnicity` | Arab American; Asian American; Black American; Hispanic American; Indian American; Native American; White American | 7 |
| `religion` | Atheist; Buddhist; Catholic; Hindu; Jewish; Muslim; Protestant | 7 |
| `socioeconomic` | Disabled; Lower middle class; Middle class; Senior Citizen; Student; Ultra-rich; Upper middle class; Veteran; Working poor | 9 |

The dimensions are inherited from the experiment. `socioeconomic` includes disability, life stage, student status, and veteran status; `geography` includes race/class intersections and an elite label; `gender_sexuality` combines gender and sexual orientation. `Nonbinary` and `Transgender / Nonbinary` overlap. These labels do not create mutually exclusive population categories. Differences in dimension-level distances can therefore reflect construct mixture, label specificity, and group count.

## Provider and version interpretation

`model_provider` preserves the original host/route. Analyses map model families to OpenAI, Anthropic, Meta, Google, Mistral, and xAI. Model-family mapping is explicit in `analyze.py`. Same-company contrasts are cross-sectional comparisons of versions, sizes, tiers, and sometimes platforms. They cannot establish chronological model evolution, improvement, or the effect of a training change.

## Preservation and audit

The raw CSV is never overwritten by cleaning or screening. Five suspected Gemini captures are handled by a separate conservative complete-cell exclusion sensitivity analysis; read `results/data_quality.json` and `results/flagged_rows.csv` for exact findings when available. Empty metadata and response-format artifacts remain visible. Full articles inside `full_prompt` remain subject to publisher rights; repository access must not be mistaken for a data redistribution license.
